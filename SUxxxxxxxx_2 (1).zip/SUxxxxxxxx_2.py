"""
Skeleton code for the second part of the second assignment. Copy the contents of this file into your own file.
Many of you complained that the skeleton code for the first hand-in was too long, so I have made this file more compact.
In other words, you will need to add much more code to the contents of this file than you did to the first hand-in.
"""
import os
import stdarray
import stddraw
import stdio
AIRPORTS = 10
### The imports above should already be in your code. If not, add them. ###

### The following code should be added to the top of your code. ###
import pygame
from picture import Picture
from color import Color

# GUI constant variables that you can modify if you really want to:
CARD_WIDTH = 100
CARD_HEIGHT = 150
OBSTACLE_DISK_RADIUS = 30
CELL_RADIUS = 20
FONT_SIZE = 20
HEADER_HEIGHT = 40
GRID_HEIGHT = 200
SHOW_DELTA = 100 # The time in milliseconds to wait between showing the GUI
LONG_PAUSE = 1000 # The time in milliseconds to wait between showing the GUI when a long pause is needed.

# GUI constant variables that you should not modify at all:
DEFAULT_PEN_RADIUS = 2.0
MAX_OUTPUT_LINES = 10
X_MAX = 1000 # The maximum x value of the GUI
Y_MAX = 740 # The maximum y value of the GUI
OUTPUT_AREA_HEIGHT = 500 # The height of the output area
OUTPUT_AREA_WIDTH = 500 # The width of the output area
GUI_OUTPUT_FONT = pygame.font.SysFont('Consolas', 15)
MAP_BACKGROUND_IMG_PATH = os.path.join("./assets_gui/", "map_background.jpg")
P1_PLANE_IMG_PATH = os.path.join("./assets_gui/", "p1.png")
P2_PLANE_IMG_PATH = os.path.join("./assets_gui/", "p2.png")
S1_SUITCASE_IMG_PATH = os.path.join("./assets_gui/", "s1.png")
S2_SUITCASE_IMG_PATH = os.path.join("./assets_gui/", "s2.png")
S3_SUITCASE_IMG_PATH = os.path.join("./assets_gui/", "s3.png")

# New global variable to store list of output messages. Do not modify this.
output_text_list = []
# New global variable to store the images. Do not modify these
map_image = None
p1_image = None
p2_image = None
s1_image = None
s2_image = None
s3_image = None

def read_images():
    """
    Read all of the images and store them in global variables.
    Do not modify this function.
    """
    global map_image, p1_image, p2_image, s1_image, s2_image, s3_image
    if not os.path.exists(MAP_BACKGROUND_IMG_PATH):
        raise FileNotFoundError(f'Could not find the map image at {MAP_BACKGROUND_IMG_PATH}.')
    if not os.path.exists(P1_PLANE_IMG_PATH):
        raise FileNotFoundError(f'Could not find the player 1 image at {P1_PLANE_IMG_PATH}.')
    if not os.path.exists(P2_PLANE_IMG_PATH):
        raise FileNotFoundError(f'Could not find the player 2 image at {P2_PLANE_IMG_PATH}.')
    if not os.path.exists(S1_SUITCASE_IMG_PATH):
        raise FileNotFoundError(f'Could not find the suitcase image at {S1_SUITCASE_IMG_PATH}.')
    if not os.path.exists(S2_SUITCASE_IMG_PATH):
        raise FileNotFoundError(f'Could not find the suitcase image at {S2_SUITCASE_IMG_PATH}.')
    if not os.path.exists(S3_SUITCASE_IMG_PATH):
        raise FileNotFoundError(f'Could not find the suitcase image at {S3_SUITCASE_IMG_PATH}.')
    map_image = Picture(MAP_BACKGROUND_IMG_PATH)
    p1_image = Picture(P1_PLANE_IMG_PATH)
    p2_image = Picture(P2_PLANE_IMG_PATH)
    s1_image = Picture(S1_SUITCASE_IMG_PATH)
    s2_image = Picture(S2_SUITCASE_IMG_PATH)
    s3_image = Picture(S3_SUITCASE_IMG_PATH)

def change_writing_functions_to_gui():
    """
    Change the writing functions to use the GUI instead of the console.
    Call this if GUI mode is enabled.
    """
    stdio.writeln = gui_write
    stdio.writef = gui_writef
    stdio.write = gui_write

def gui_writef(fmt, *args):
    """
    Use exactly the same syntax as stdio.writef, but instead of writing to the console, write to the GUI.
    Do not modify this function.
    """
    text = (fmt.strip()) % args
    gui_write(text)

def gui_write(text=''):
    """
    Use exactly the same syntax as stdio.write, but instead of writing to the console, write to the GUI.
    Do not modify this function.
    """
    global output_text_list
    text = text.replace('\n', ' ').strip()
    max_width = OUTPUT_AREA_WIDTH - 20
    max_entries = (OUTPUT_AREA_HEIGHT/2) // GUI_OUTPUT_FONT.size(' ')[1]
    words = text.split(' ')
    while len(words) > 0:
        line_words = []
        while len(words) > 0 and GUI_OUTPUT_FONT.size(' '.join(line_words + [words[0]]))[0] < max_width:
            line_words.append(words.pop(0))
        output_text_list.append((' '.join(line_words)).strip())
        while GUI_OUTPUT_FONT.size(output_text_list[-1])[0] < max_width: output_text_list[-1] += ' '
    output_text_list.append('')
    while len(output_text_list) > max_entries or (len(output_text_list) > 0 and output_text_list[0].strip() == ''):
        output_text_list.pop(0)
    draw_message_area()
    stddraw.show(SHOW_DELTA)

def rect_border(x0, y0, xl, yl):
    """
    Draw a filled rectangle with a border.
    Do not modify this function.
    """
    stddraw.setPenColor(stddraw.LIGHT_GRAY)
    stddraw.filledRectangle(x0, y0, xl, yl)
    draw_border_lines(x0, y0, xl, yl)

def draw_border_lines(x0, y0, xl, yl):
    """
    Draw the border lines of a rectangle. Not filled.
    Do not modify this function.
    """
    stddraw.setPenRadius(DEFAULT_PEN_RADIUS)
    stddraw.setPenColor(stddraw.DARK_GRAY)
    stddraw.line(x0, y0, x0 + xl, y0)
    stddraw.line(x0, y0, x0, y0 + yl)
    stddraw.line(x0 + xl, y0, x0 + xl, y0 + yl)
    stddraw.line(x0, y0 + yl, x0 + xl, y0 + yl)

def draw_message_area():
    """
    Draw the message area.
    Do not modify this function.
    """
    x0 = 0
    y0 = OUTPUT_AREA_HEIGHT/2
    rect_border(x0, OUTPUT_AREA_HEIGHT/2, OUTPUT_AREA_WIDTH, OUTPUT_AREA_HEIGHT/2)
    if len(output_text_list) > 0:
        x_center = x0 + OUTPUT_AREA_WIDTH/2
        stddraw.setFontSize(15)
        stddraw.setPenColor(stddraw.BLACK)
        for i in range(len(output_text_list)):
            y_center = y0 + (i + 1) * (15)
            stddraw.text(x_center, y_center, output_text_list[len(output_text_list) -1 -i])
        stddraw.setFontSize(FONT_SIZE)

def get_flight_connection_colour(flight_cost: float):
    """
    Get the colour of the flight connection based on the flight cost.
    Use this to colour the flight connections on the map.
    Do not modify this function.

    Parameters
    ----------
    flight_cost
        The cost of the flight connection.

    Returns
    -------
    Color
        The colour of the flight connection.
    """
    h = max(0.3, min(0.2 + (flight_cost/20.0)*0.9, 1.0))
    i = int(h * 6.0)
    f = int(255*((h * 6.0) - i))
    rgbs = [(255, f, 0), (255-f, 255, 0), (0, 255, f), (0, 255-f, 255), (f, 0, 255), (255, 0, 255-f)]
    return Color(*rgbs[i % 6])

def draw_airport_map(p1_airport_id, p2_airport_id, airport_coordinate_matrix, flight_cost_matrix, cur_player):
    """
    An incomplete function to draw the airport map. You need to complete this function.

    Parameters
    ----------
    p1_airport_id
        The ID of the first player's airport.
    p2_airport_id
        The ID of the second player's airport.
    airport_coordinate_matrix
        The matrix of airport coordinates.
    flight_cost_matrix
        The matrix of flight costs. I.e., the cost matrix.
    cur_player
        The current player. Either 0 or 1.
    """
    # The ID of the current player's airport.
    cur_airport_id = p1_airport_id if cur_player == 0 else p2_airport_id

    # The coordinates of the airports scaled to the coordinates that wil be drawn on the map.
    map_coordinates = stdarray.create2D(AIRPORTS, 2, 0)

    # The padding between the border of the map and the border of the map image. (5%)
    padding = 0.05

    # The width and height of the map image.
    l = 500
    x0 = X_MAX - l
    y0 = 0

    # The minimum and maximum x and y coordinates of the airports.
    x_min = float('inf')
    x_max = float('-inf')
    y_min = float('inf')
    y_max = float('-inf')

    # Draw the map image.
    rect_border(x0, y0, l, l)
    stddraw.picture(map_image, x0 + l/2, y0 + l/2)
    draw_border_lines(x0, y0, l, l)

    # Resize the dimensions of the map to account for padding.
    x0 = x0 + l * padding
    y0 = y0 + l * padding
    l = l * (1 - padding*2)

    # Find the minimum and maximum x and y coordinates of the airports.
    for airport in range(AIRPORTS):
        x, y = airport_coordinate_matrix[airport]
        x_min = min(x_min, x)
        x_max = max(x_max, x)
        y_min = min(y_min, y)
        y_max = max(y_max, y)

    # Scale the coordinates of the airports to the coordinates that wil be drawn on the map.
    for airport in range(AIRPORTS):
        map_coordinates[airport][0] = x0 + ((airport_coordinate_matrix[airport][0] - x_min) / (x_max - x_min)) * l
        map_coordinates[airport][1] = y0 + ((airport_coordinate_matrix[airport][1] - y_min) / (y_max - y_min)) * l
    # TODO: The rest of the function is your duty to implement

    # Draw the connections between the airports and display the cost on top of the line:
    for airport in range(AIRPORTS):
        x1, y1 = map_coordinates[airport]
        for other_airport in range(AIRPORTS):
            if airport == other_airport:
                continue
            # Get the drawing coordinates of the other airport.
            x2, y2 = map_coordinates[other_airport]
            # Get the flight cost between these two airports
            f_cost = flight_cost_matrix[airport][other_airport]
            # If airport is the same as the current player's airport, draw a thicker line.
            if airport == cur_airport_id:
                stddraw.setPenRadius(2.0)
            else:
                stddraw.setPenRadius(0.5)
            # Draw the line and set the colour of the line based on the flight cost.
            stddraw.setPenColor(get_flight_connection_colour(f_cost))
            stddraw.line(x1, y1, x2, y2)
    # TODO: The rest of the function is your duty to implement
    # For example, you still need to draw the dots for the airports and the labels for the airports.
    # You also need to draw the plane icon on top of both players' airports.
    # You also need to draw the cost of the flight connection between the two airports on top of the line.
    # Only draw the cost of the flight connection if the line is drawn between the current player's airport and any other airport.
    # Tip: the midpoint of a line is given by the formula (x_mid, y_mid) = ((x1 + x2)/2, (y1 + y2)/2)
